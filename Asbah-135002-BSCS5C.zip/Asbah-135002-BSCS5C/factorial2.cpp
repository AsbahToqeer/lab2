#include<iostream>
#include "Header.h"
using namespace std;


int main(){
	int f;
	int n;
	factorial_calculate fac;
	cout << "Enter number: ";
	cin >> n;
	if (n < 0)
		cout << "Factorial of negative numbers don't exist";
	else if (n == 0 || n == 1 || n>1)
		cout << "Factorial is : " << fac.fact(n);
	else
		cout << "Invalid Input";
	
	getchar();
	getchar();
	return 0;

}
