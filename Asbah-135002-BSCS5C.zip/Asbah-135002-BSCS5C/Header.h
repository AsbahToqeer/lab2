class factorial_calculate{
public:
	int fact(int n);
};

int factorial_calculate:: fact(int n)
{

	if (n == 0 || n == 1)
		return 1;
	else if (n > 1)
		return n*fact(n - 1);


}