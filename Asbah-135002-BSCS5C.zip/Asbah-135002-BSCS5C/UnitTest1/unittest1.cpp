#include "stdafx.h"
#include "CppUnitTest.h"
#include "..\ConsoleApplication170\factorial2.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		factorial_calculate A;
		TEST_METHOD(TestMethodequal1)
		{
			Assert::AreEqual(6, A.fact(3));
		}
		TEST_METHOD(TestMethodequal2)
		{
			Assert::AreEqual(120, A.fact(5));
		}
		TEST_METHOD(TestMethodnot_equal1)
		{
			Assert::AreNotEqual(5, A.fact(3));
		}
		TEST_METHOD(TestMethodnot_equal2)
		{
			Assert::AreNotEqual(100, A.fact(5));
		}
		TEST_METHOD(TestMethodnot_equal3)
		{
			Assert::AreNotEqual(100, A.fact(-5));
		}
	};
}