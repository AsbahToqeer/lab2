#include<iostream>
#define SIZE 5
using namespace std;

class stack{

public:
	int num[SIZE];
	int top;
	stack();
	int isEmpty();
	int isFull();
	int push(int);
	int pop();
	void display();
};

stack::stack(){
	top = -1;
}

int stack::isEmpty(){
	if (top == -1)
		return 1;
	else
		return 0;
}

int stack::isFull(){
	if (top == (SIZE - 1))
		return 1;
	else
		return 0;

}

int stack::push(int n){
	if (isFull())
	{
		return 0;
	}
	top++;
	num[top] = n;
	return n;
}

int stack::pop(){
	int temp;
	if (isEmpty())
		return 0;
	temp = num[top];
	return temp;
}

void stack:: display(){
	int i;
	for (i = (top); i >= 0; i--)
		cout << num[i] << " ";
	cout << endl;
}

void main(){

	stack s;
	s.push(5);
	s.push(6);
	s.push(7);
	s.push(8);
	s.push(9);
	s.display();
	cout<<" Popped out element is: "<<s.pop();
	getchar();



}