#include "stdafx.h"
#include "CppUnitTest.h"
#include "..\ConsoleApplication171\sta.cpp"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		stack s;
		TEST_METHOD(TestMethod1)
		{
			s.push(5);
			s.push(6);
			s.push(7);
			s.push(8);
			s.push(9);
			Assert::AreEqual(9, s.pop());
		}

		TEST_METHOD(TestMethod2)
		{
			s.push(5);
			s.push(6);
			s.push(7);
			s.push(8);
			Assert::AreEqual(8, s.pop());
		}
	};
}